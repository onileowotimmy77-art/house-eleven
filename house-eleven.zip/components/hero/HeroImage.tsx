"use client";

import Image from "next/image";

import Reveal from "@/components/motion/Reveal";
import Parallax from "@/components/motion/Parallax";

export default function HeroImage() {
  return (
    <div
  className="
    relative
    h-[105vh]
    w-[92%]
    ml-auto
    overflow-hidden
  "
>
  <Image
    src="/hero-placeholder.jpg"
    alt="House Eleven Campaign"
    fill
    priority
    sizes="92vw"
    className="object-cover object-center"
  />
</div>
  );
}