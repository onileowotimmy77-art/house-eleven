"use client";

interface NavbarBlurProps {
  scrolled: boolean;
}

export default function NavbarBlur({
  scrolled,
}: NavbarBlurProps) {
  return (
    <div
      className={`
        absolute
        inset-0
        -z-10

        transition-all
        duration-700

        ${
          scrolled
            ? "bg-black/20 backdrop-blur-2xl border-b border-white/5"
            : "bg-black/5 backdrop-blur-md border-b border-transparent"
        }
      `}
    />
  );
}