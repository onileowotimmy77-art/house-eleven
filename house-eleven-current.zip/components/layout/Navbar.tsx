"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

import Container from "./Container";

import NavbarBlur from "../navigation/NavbarBlur";
import NavLogo from "../navigation/NavLogo";
import NavLinks from "../navigation/NavLinks";
import NavButton from "../navigation/NavButton";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll);

    return () =>
      window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.header
      initial={{
        y: -72,
        opacity: 0,
      }}
      animate={{
        y: 0,
        opacity: 1,
      }}
      transition={{
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      }}
      className="
        fixed
        inset-x-0
        top-0
        z-50
        w-full
      "
    >
      <NavbarBlur scrolled={scrolled} />

      <Container>
        <div
          className="
            flex
            items-center
            justify-between
            py-7
          "
        >
          <NavLogo />

          <NavLinks />

          <NavButton />
        </div>
      </Container>
    </motion.header>
  );
}