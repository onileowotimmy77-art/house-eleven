"use client";

import Button from "@/components/ui/Button";
import Reveal from "@/components/motion/Reveal";
import Stagger from "@/components/motion/Stagger";
import { useCursorContext } from "@/components/cursor/CursorProvider";
import Parallax from "@/components/motion/Parallax";

export default function HeroContent() {
  const {
    setLabel,
    setHovering,
  } = useCursorContext();

  return (
    <div className="flex flex-col justify-center">
      <Stagger>
        <Reveal>
          <Parallax speed={25}>
            <h1
                className="
                mt-6 lg:mt-12
                max-w-[8ch]
                font-extrabold
                uppercase
                tracking-[-0.06em]
                leading-[0.88]
                text-[clamp(3.8rem,6vw,7.5rem)]
                "
            >
                EVERY
                <br />
                HOUSE
                <br />
                BEGINS
                <br />
                SOMEWHERE.
            </h1>
          </Parallax>
        </Reveal>

        <Reveal>
          <Parallax speed={18}>
            <p
                className="
                mt-10
                max-w-lg
                text-lg
                leading-8
                text-white/65
                "
            >
                A modern fashion and creative house built for the next generation.
            </p>
          </Parallax>
        </Reveal>

        <Reveal>
            <Parallax speed={10}>
                <div className="mt-12 lg:mt-16">
                    <Button
                    onMouseEnter={() => {
                        setHovering(true);
                        setLabel("ENTER");
                    }}
                    onMouseLeave={() => {
                        setHovering(false);
                        setLabel("");
                    }}
                    >
                    ENTER THE HOUSE
                    </Button>
                </div>
          </Parallax>
        </Reveal>
      </Stagger>
    </div>
  );
}