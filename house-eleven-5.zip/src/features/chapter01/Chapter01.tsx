"use client";

import Section from "@/components/layout/Section";
import Container from "@/components/layout/Container";


import ChapterCampaign from "./ChapterCampaign";
import ResidenceShowcase from "@/src/features/chapter01/ResidenceShowcase/ResidenceShowcase";
import SectionHeader from "@/components/ui/SectionHeader";
import Transition from "../transition/Transition";



export default function Chapter01() {
  return (
    <Section padding="py-56">
      <Container className="max-w-[1700px]">

        <SectionHeader className="mt-32"
          eyebrow="Chapter01"
          title="Residence"
        />

        <ChapterCampaign />

        <Transition />

        <ResidenceShowcase />

      </Container>
    </Section>
  );
}