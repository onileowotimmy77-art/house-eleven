"use client";

import GalleryItem from "@/src/features/product/GalleryItem";

export default function ResidenceGrid() {
  return (
    <div className="mt-32">

      <GalleryItem
        featured
        editorial
        eyebrow="Signature Piece"
        title="Residence Polo"
        description="Tailored for Him & Her. Designed as the defining garment of Chapter 01."
        price=""
        image="/chapter01.jpg"
        href="#"
      />

    </div>
  );
}