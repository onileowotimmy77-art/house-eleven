"use client";

import ResidenceGrid from "./ResidenceGrid";

export default function ResidenceShowcase() {
  return <ResidenceGrid />;
}