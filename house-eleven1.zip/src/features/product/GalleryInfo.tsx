"use client";

import Link from "next/link";

interface GalleryInfoProps {
  title: string;
  description: string;
  price?: string;
  href: string;

  availableColours?: number;
  availableFits?: string[];

  editorial?: boolean;
  eyebrow?: string;
}

export default function GalleryInfo({
  title,
  description,
  price,
  href,
  availableColours,
  availableFits,
  editorial = false,
  eyebrow = "Chapter 01",
}: GalleryInfoProps) {
  return (
    <div 
      className={`
        mt-8
        ${editorial ? "mx-auto max-w-3xl text-center" : ""}
      `}
    >
      <p
        className="
          text-[11px]
          uppercase
          tracking-[0.35em]
          text-white/35
        "
      >
        {eyebrow}
      </p>

      <h3
        className="
          mt-5
          text-3xl
          font-black
          uppercase
          tracking-[-0.04em]
        "
      >
        {title}
      </h3>

      <p
        className="
          mt-3
          text-white/60
          leading-7
        "
      >
        {description}
      </p>

      {!editorial && availableColours && (
        <p className="mt-4 text-white/45">
          Available in {availableColours} colours
        </p>
      )}

      {!editorial && availableFits && (
        <p className="mt-2 text-white/45">
          {availableFits.join(" • ")}
        </p>
      )}

      <div className="mt-8 flex items-center justify-between">
        {!editorial && price && (
          <span
            className="
              text-xl
              font-semibold
            "
          >
            {price}
          </span>
        )}

        <Link
          href={href}
          className="
            uppercase
            tracking-[0.2em]
            text-sm
            transition-opacity
            duration-500
            hover:opacity-60
          "
        >
          {editorial ? "View →" : "Discover →"}
        </Link>
      </div>
    </div>
  );
}