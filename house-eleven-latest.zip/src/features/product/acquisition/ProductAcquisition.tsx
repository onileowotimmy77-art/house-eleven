"use client";

import {
  useEffect,
  useMemo,
  useState,
} from "react";

import Container from "@/components/layout/Container";
import Section from "@/components/layout/Section";

import CommerceNotification from "../../commerce/CommerceNotification";

import { useBagStore } from "@/src/lib/stores/useBagStore";
import { useSavedPiecesStore } from "@/src/lib/stores/useSavedPiecesStore";
import { useRestockStore } from "@/src/lib/stores/useRestockStore";
import { useEarlyAccessStore } from "@/src/lib/stores/useEarlyAccessStore";
import { useInventoryStore } from "@/src/lib/stores/useInventoryStore";

import type { Product } from "@/src/data/products";
import type { ProductInventory } from "@/src/data/inventory";

import { canAcquireQuantity } from "@/src/lib/commerce/inventory";

interface ProductAcquisitionProps {
  product: Product;
  inventory?: ProductInventory;
}

type CommerceNotificationType =
  | "acquired"
  | "saved"
  | "removed"
  | "restock"
  | "early-access"
  | "unavailable"
  | "already-in-bag";

export default function ProductAcquisition({
  product,
  inventory,
}: ProductAcquisitionProps) {
  const addToBag = useBagStore(
    (state) => state.addToBag
  );

  const bagItems = useBagStore(
    (state) => state.items
  );

  const requestRestock = useRestockStore(
    (state) => state.requestRestock
  );

  const hasRequestedRestock = useRestockStore(
    (state) =>
      state.hasRequestedRestock(
        product.slug
      )
  );

  const requestEarlyAccess =
    useEarlyAccessStore(
      (state) =>
        state.requestEarlyAccess
    );

  const hasRequestedEarlyAccess =
    useEarlyAccessStore(
      (state) =>
        state.hasRequestedEarlyAccess(
          product.slug
        )
    );

  const savePiece = useSavedPiecesStore(
    (state) => state.savePiece
  );

  const removePiece = useSavedPiecesStore(
    (state) => state.removePiece
  );

  const isSaved = useSavedPiecesStore(
    (state) =>
      state.isSaved(product.slug)
  );

  const hydrateInventory =
    useInventoryStore(
      (state) =>
        state.hydrateInventory
    );

  /*
   * Live inventory.
   *
   * This subscribes the acquisition UI directly
   * to the synchronized Zustand inventory store.
   *
   * The server-provided inventory remains available
   * as the initial fallback.
   */
  const liveInventory =
    useInventoryStore((state) =>
      state.inventory.find(
        (item) =>
          item.productSlug ===
          product.slug
      )
    );

  useEffect(() => {
    void hydrateInventory();
  }, [hydrateInventory]);

  const [selectedSize, setSelectedSize] =
    useState<string | null>(null);

  const [
    notification,
    setNotification,
  ] =
    useState<CommerceNotificationType | null>(
      null
    );

  /*
   * Use live inventory whenever it exists.
   *
   * The prop remains as a safe initial fallback.
   */
  const currentInventory =
    liveInventory ?? inventory;

  const sizes = useMemo(
    () =>
      currentInventory?.sizes ??
      product.sizes.map((size) => ({
        size,
        stock: 1,
      })),
    [
      currentInventory,
      product.sizes,
    ]
  );

  const inventoryStatus =
    currentInventory?.status;

  const canAcquire =
    selectedSize !== null &&
    inventoryStatus !== "coming-soon" &&
    inventoryStatus !== "sold-out";

  useEffect(() => {
    if (!notification) {
      return;
    }

    const timer = window.setTimeout(
      () => {
        setNotification(null);
      },
      3000
    );

    return () =>
      window.clearTimeout(timer);
  }, [notification]);

  /*
   * If the currently selected size becomes
   * unavailable in another tab, clear the
   * selection so the UI cannot continue with
   * stale availability.
   */
  useEffect(() => {
    if (!selectedSize) {
      return;
    }

    const selectedInventory =
      sizes.find(
        (item) =>
          item.size === selectedSize
      );

    if (
      !selectedInventory ||
      selectedInventory.stock <= 0
    ) {
      setSelectedSize(null);
    }
  }, [
    selectedSize,
    sizes,
    ]);

  const availability = useMemo(() => {
    switch (inventoryStatus) {
      case "available":
        return {
          label: "Available",
          className: "text-white/55",
        };

      case "low-stock":
        return {
          label:
            "Only a few pieces remain.",
          className: "text-white/70",
        };

      case "coming-soon":
        return {
          label:
            "Chapter I has not yet opened.",
          className: "text-white/45",
        };

      case "sold-out":
        return {
          label:
            "This edition has been fully acquired.",
          className: "text-white/45",
        };

      default:
        return {
          label: "",
          className: "text-white/45",
        };
    }
  }, [inventoryStatus]);

  function handleSavePiece() {
    if (isSaved) {
      removePiece(product.slug);

      setNotification("removed");

      return;
    }

    savePiece(product.slug);

    setNotification("saved");
  }

  function handleRestockRequest() {
    requestRestock(product.slug);

    setNotification("restock");
  }

  function handleEarlyAccessRequest() {
    requestEarlyAccess(product.slug);

    setNotification("early-access");
  }

  function handleAcquire() {
    if (
      inventoryStatus ===
      "sold-out"
    ) {
      handleRestockRequest();

      return;
    }

    if (
      !selectedSize ||
      inventoryStatus ===
        "coming-soon"
    ) {
      return;
    }

    /*
     * Prevent the exact same product and
     * size from being acquired more than once
     * from the Product page.
     *
     * The Bag is intentionally responsible for
     * quantity changes. Once this exact
     * product/size combination exists in the
     * Bag, the customer should go there to
     * increase the quantity rather than creating
     * another acquisition from the Product page.
     */
    const alreadyInBag =
      bagItems.some(
        (item) =>
          item.productSlug ===
            product.slug &&
          item.size ===
            selectedSize
      );

    if (alreadyInBag) {
      setNotification(
        "already-in-bag"
      );

      return;
    }

    /*
     * Read the current live inventory at the
     * exact moment of acquisition.
     *
     * This protects against a UI that became
     * stale between render and click.
     */
    const latestInventory =
      useInventoryStore
        .getState()
        .inventory.find(
          (item) =>
            item.productSlug ===
            product.slug
        );

    const selectedSizeInventory =
      latestInventory?.sizes.find(
        (item) =>
          item.size ===
          selectedSize
      );

    if (
      !selectedSizeInventory ||
      selectedSizeInventory.stock <= 0
    ) {
      setSelectedSize(null);

      setNotification(
        "unavailable"
      );

      return;
    }

    if (
      !canAcquireQuantity(
        product.slug,
        selectedSize,
        1
      )
    ) {
      setNotification(
        "unavailable"
      );

      return;
    }

    const wasAdded =
      addToBag({
        productSlug:
          product.slug,

        size:
          selectedSize,

        quantity: 1,
      });

    if (!wasAdded) {
      setNotification(
        "unavailable"
      );

      return;
    }

    setNotification("acquired");
  }

  const notificationConfig =
    notification === "acquired"
      ? {
          eyebrow: "House Eleven",
          title: product.name,
          subtitle: `Size ${selectedSize} • ${product.price}`,
          message:
            "This piece has entered your Residence.",
          ctaLabel: "View Bag",
          ctaHref: "/bag",
        }
      : notification ===
        "already-in-bag"
      ? {
          eyebrow:
            "Already Selected",
          title: product.name,
          subtitle: `Size ${selectedSize}`,
          message:
            "This piece is already in your selection. Visit your Bag to increase the quantity if you would like another.",
          ctaLabel: "Go to Bag",
          ctaHref: "/bag",
        }
      : notification === "saved"
      ? {
          eyebrow: "Saved",
          title: product.name,
          subtitle: product.collection,
          message:
            "Added to your personal archive.",
          ctaLabel:
            "View Saved Pieces",
          ctaHref:
            "/account/saved",
        }
      : notification === "removed"
      ? {
          eyebrow: "Saved",
          title: product.name,
          subtitle: product.collection,
          message:
            "Removed from your personal archive.",
        }
      : notification ===
        "early-access"
      ? {
          eyebrow:
            "Early Access",
          title: product.name,
          subtitle:
            product.collection,
          message:
            "Your request has been received. The House will contact you before this edition opens.",
        }
      : notification === "restock"
      ? {
          eyebrow:
            "Restock Requested",
          title: product.name,
          subtitle:
            product.collection,
          message:
            "You will be notified when this piece returns to the House.",
        }
      : notification ===
        "unavailable"
      ? {
          eyebrow:
            "Selection Updated",
          title: product.name,
          subtitle:
            selectedSize
              ? `Size ${selectedSize}`
              : product.collection,
          message:
            "This size is no longer available in the requested quantity. Please review the current availability.",
        }
      : null;

  return (
    <>
      <Section customPadding="py-45">
        <Container>
          <div className="border-t border-white/10 pt-20">
            <p
              className="
                mt-10
                font-mono
                text-[11px]
                uppercase
                tracking-[0.4em]
                text-white/40
              "
            >
              Current Edition
            </p>

            <h2
              className="
                mt-6
                text-[clamp(3rem,7vw,6rem)]
                font-black
                uppercase
                leading-[0.9]
                tracking-[-0.05em]
              "
            >
              {product.name}
            </h2>

            <p
              className="
                my-10
                text-xl
                font-medium
                text-white/65
              "
            >
              {product.price}
            </p>

            <p
              className={`
                font-mono
                text-[11px]
                uppercase
                tracking-[0.35em]
                ${availability.className}
              `}
            >
              {availability.label}
            </p>

            <div
              className="
                mt-8
                border
                border-white/10
                bg-white/[0.02]
                px-5
                py-4
              "
            >
              <div
                className="
                  flex
                  items-center
                  justify-between
                  gap-6
                "
              >
                <span
                  className="
                    font-mono
                    text-[9px]
                    uppercase
                    tracking-[0.35em]
                    text-white/35
                  "
                >
                  Live Inventory
                </span>

                <span
                  className="
                    font-mono
                    text-[9px]
                    uppercase
                    tracking-[0.25em]
                    text-white/35
                  "
                >
                  Synchronized
                </span>
              </div>

              <div
                className="
                  mt-5
                  grid
                  grid-cols-2
                  gap-x-8
                  gap-y-3
                  sm:grid-cols-4
                  "
              >
                {sizes.map(
                  ({
                    size,
                    stock,
                  }) => (
                    <div
                      key={`live-stock-${size}`}
                      className="
                        flex
                        items-center
                        justify-between
                        border-b
                        border-white/5
                        pb-2
                      "
                    >
                      <span
                        className="
                          font-mono
                          text-[10px]
                          uppercase
                          tracking-[0.3em]
                          text-white/45
                        "
                      >
                        {size}
                      </span>

                      <span
                        className={`
                          font-mono
                          text-[10px]
                          tracking-[0.2em]
                          ${
                            stock > 0
                              ? "text-white/70"
                              : "text-white/20"
                          }
                        `}
                      >
                        {stock}
                      </span>
                    </div>
                  )
                )}
              </div>

              {selectedSize && (
                <div
                  className="
                    mt-5
                    border-t
                    border-white/5
                    pt-4
                  "
                >
                  <p
                    className="
                      font-mono
                      text-[9px]
                      uppercase
                      tracking-[0.3em]
                      text-white/30
                    "
                  >
                    Selected Size
                  </p>

                  <p
                    className="
                      mt-2
                      font-mono
                      text-[11px]
                      uppercase
                      tracking-[0.3em]
                      text-white/65
                    "
                  >
                    {selectedSize}
                    {" · "}
                    {sizes.find(
                      (item) =>
                        item.size ===
                        selectedSize
                    )?.stock ?? 0}
                    {" Remaining"}
                  </p>
                </div>
              )}
            </div>

            <p
              className="
                my-6
                font-mono
                text-[11px]
                uppercase
                tracking-[0.4em]
                text-white/40
              "
            >
              Select Size
            </p>

            <div
              className="
                mt-10
                flex
                flex-wrap
                gap-4
              "
            >
              {sizes.map(
                ({
                  size,
                  stock,
                }) => {
                  const isSelected =
                    selectedSize ===
                    size;

                  const isDisabled =
                    stock === 0 ||
                    inventoryStatus ===
                      "coming-soon" ||
                    inventoryStatus ===
                      "sold-out";

                  return (
                    <button
                      key={size}
                      type="button"
                      disabled={
                        isDisabled
                      }
                      onClick={() =>
                        setSelectedSize(
                          size
                        )
                      }
                      className={`
                        border
                        px-10
                        py-4
                        font-mono
                        text-xs
                        uppercase
                        tracking-[0.45em]
                        transition-all
                        duration-300

                        ${
                          isDisabled
                            ? "cursor-not-allowed border-white/5 text-white/20"
                            : isSelected
                            ? "border-white bg-white text-black"
                            : "border-white/10 text-white/70 hover:border-white/40 hover:text-white"
                        }
                      `}
                    >
                      {size}
                    </button>
                  );
                }
              )}
            </div>

            <button
              type="button"
              disabled={
                inventoryStatus ===
                  "coming-soon" ||
                inventoryStatus ===
                  "sold-out"
                  ? false
                  : !canAcquire
              }
              onClick={
                inventoryStatus ===
                "coming-soon"
                  ? handleEarlyAccessRequest
                  : inventoryStatus ===
                  "sold-out"
                  ? handleRestockRequest
                  : handleAcquire
              }
              className={`
                mt-20
                inline-flex
                items-center
                gap-4
                border-b
                pb-3
                font-mono
                text-[11px]
                uppercase
                tracking-[0.45em]
                transition-all
                duration-300

                ${
                  canAcquire
                    ? "border-white/20 text-white/80 hover:gap-6 hover:border-white/60 hover:text-white"
                    : "cursor-not-allowed border-white/10 text-white/25"
                }
              `}
            >
              {inventoryStatus ===
              "coming-soon"
                ? hasRequestedEarlyAccess
                  ? "Early Access Requested"
                  : "Request Early Access"
                : inventoryStatus ===
                  "sold-out"
                ? hasRequestedRestock
                  ? "Restock Requested"
                  : "Notify Me"
                : selectedSize
                ? "Acquire Piece"
                : "Select Size"}

              {(inventoryStatus ===
                "available" ||
                inventoryStatus ===
                  "low-stock") &&
                selectedSize && (
                  <span aria-hidden>
                    →
                  </span>
                )}
            </button>

            <button
              type="button"
              onClick={
                handleSavePiece
              }
              className="
                mt-8
                block
                font-mono
                text-[11px]
                uppercase
                tracking-[0.45em]
                text-white/40
                transition-colors
                duration-300
                hover:text-white/70
              "
            >
              {isSaved
                ? "Saved ✓"
                : "Save Piece"}
            </button>
          </div>
        </Container>
      </Section>

      {notificationConfig && (
        <CommerceNotification
          open
          image={
            product.bagImage
          }
          eyebrow={
            notificationConfig.eyebrow
          }
          title={
            notificationConfig.title
          }
          subtitle={
            notificationConfig.subtitle
          }
          message={
            notificationConfig.message
          }
          ctaLabel={
            notificationConfig.ctaLabel
          }
          ctaHref={
            notificationConfig.ctaHref
          }
          onDismiss={() =>
            setNotification(null)
          }
        />
      )}
    </>
  );
}
