"use client";

import Image from "next/image";
import Container from "@/components/layout/Container";
import Section from "@/components/layout/Section";

export default function ProductHero() {
  return (
    <>
      {/* Fullscreen Campaign */}
      <section className="relative h-screen overflow-hidden">
        <Image
          src="/chapter01.jpg"
          alt="Residence Polo"
          fill
          priority
          className="object-cover"
        />

        <div
          className="
            absolute
            inset-0
            bg-gradient-to-t
            from-[#050505]
            via-black/30
            to-transparent
          "
        />

        {/* Scroll Indicator */}
        <div
          className="
            absolute
            bottom-10
            left-1/2
            -translate-x-1/2
            flex
            flex-col
            items-center
            gap-4
          "
        >
          <span
            className="
              font-mono
              text-[10px]
              uppercase
              tracking-[0.45em]
              text-white/45
            "
          >
            Scroll
          </span>

          <div className="h-12 w-px bg-white/25" />
        </div>
      </section>

      {/* Product Identity */}
      <Section padding="pt-40 pb-24">
        <Container>

          <p
            className="
              font-mono
              text-xs
              uppercase
              tracking-[0.45em]
              text-white/40
            "
          >
            Chapter 01
          </p>

          <h1
            className="
              mt-6
              text-[clamp(4rem,9vw,8rem)]
              font-black
              uppercase
              leading-[0.9]
              tracking-[-0.06em]
            "
          >
            Residence Polo
          </h1>

          <p
            className="
              mt-10
              max-w-2xl
              text-xl
              leading-9
              text-white/60
            "
          >
            Tailored for Him & Her. Designed as the defining garment of
            Chapter 01.
          </p>

        </Container>
      </Section>
    </>
  );
}