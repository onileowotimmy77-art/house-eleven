"use client";

import Container from "@/components/layout/Container";
import Section from "@/components/layout/Section";
import { Eyebrow, Display, Body } from "@/components/ui/typography";

export default function ProductStory() {
  return (
    <Section padding="py-40">
      <Container>

        <div className="max-w-5xl">

          <Eyebrow>
            The Story
          </Eyebrow>

          <Display className="mt-8">
            Every garment begins long before the first stitch.
          </Display>

          <Body
            className="
              mt-10
              max-w-3xl
              text-xl
              leading-9
              text-white/60
            "
          >
            The Residence Polo represents the opening statement of
            Chapter 01. Designed with quiet confidence, every seam,
            proportion and fabric choice reflects House Eleven's belief
            that luxury should be experienced rather than announced.
          </Body>

        </div>

      </Container>
    </Section>
  );
}