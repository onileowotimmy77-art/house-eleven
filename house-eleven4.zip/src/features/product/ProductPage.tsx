import ProductHero from "./hero/ProductHero";
import ProductStory from "./story/ProductStory";
import ProductCraftsmanship from "./craftsmanship/ProductCraftsmanship";

export default function ProductPage() {
  return (
    <>
      <ProductHero />

      <ProductStory />

      <ProductCraftsmanship />
    </>
  );
}