"use client";

import Container from "@/components/layout/Container";
import Section from "@/components/layout/Section";
import { Eyebrow, Display } from "@/components/ui/typography";

export default function Craftsmanship() {
  return (
    <Section padding="py-48">
      <Container>

        <Eyebrow>
          Craftsmanship
        </Eyebrow>

        <Display className="mt-8 max-w-5xl">
          Every proportion, seam and silhouette is considered with intention.
        </Display>

        <div className="mt-24 grid gap-16 lg:grid-cols-3">

          <div>
            <h3 className="text-2xl font-bold uppercase tracking-[-0.03em]">
              Precision
            </h3>

            <p className="mt-6 leading-8 text-white/60">
              Every panel is designed to create a clean architectural silhouette
              that moves naturally with the body.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold uppercase tracking-[-0.03em]">
              Material
            </h3>

            <p className="mt-6 leading-8 text-white/60">
              Premium fabrics were selected not only for comfort but for how
              they age, drape and retain their character over time.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold uppercase tracking-[-0.03em]">
              Longevity
            </h3>

            <p className="mt-6 leading-8 text-white/60">
              Designed to outlive seasonal trends, the Residence Polo is built
              to remain relevant for years rather than months.
            </p>
          </div>

        </div>

      </Container>
    </Section>
  );
}