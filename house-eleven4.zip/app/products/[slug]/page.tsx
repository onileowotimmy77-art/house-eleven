import ProductPage from "@/src/features/product/ProductPage";

export default function Page() {
  return <ProductPage />;
}